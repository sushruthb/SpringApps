package com.vuespring.vuespring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VuespringApplication {

	public static void main(String[] args) {
		SpringApplication.run(VuespringApplication.class, args);
	}

}
