package com.vuespring.vuespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VuespringApplicationTests {

	@Test
	void contextLoads() {
	}

}
