package com.spring.apps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppsApplicationTests {

	@Test
	void contextLoads() {
	}

}
