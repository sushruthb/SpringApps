## Helm
* basics
  * what is helm?
  * how to deploy existing charts
  * Exercise 09 - happy helming
* authoring helm charts
  * elements of a helm chart
  * templates & values
  * Exercise 10 - write a simple chart
