images for resource files
